package com.example.productapi.config;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class ApiKeyFilter extends OncePerRequestFilter {
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, java.io.IOException {
        String path = request.getRequestURI();
        if (path.startsWith("/api/v1/products")) { // 공개 조회
            String key = request.getHeader("X-API-Key");
            String expected = System.getenv().getOrDefault("PUBLIC_API_KEY", "dev-public-key");
            if (key == null || !key.equals(expected)) {
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                response.setContentType("application/json");
                response.getWriter().write("{\"error\":{\"code\":\"UNAUTHORIZED\",\"message\":\"Missing or invalid API key\"}}\n");
                return;
            }
        }
        filterChain.doFilter(request, response);
    }
}
