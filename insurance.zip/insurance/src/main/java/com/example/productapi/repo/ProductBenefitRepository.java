package com.example.productapi.repo;

import com.example.productapi.domain.ProductBenefit;
import com.example.productapi.domain.ProductBenefitId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductBenefitRepository extends JpaRepository<ProductBenefit, ProductBenefitId> {}
