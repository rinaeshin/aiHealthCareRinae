package com.example.productapi.repo;

import com.example.productapi.domain.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface ProductRepository extends JpaRepository<Product, UUID> {
    Page<Product> findByStatus(String status, Pageable pageable);
    Page<Product> findByStatusAndCompanyContainingIgnoreCase(String status, String company, Pageable pageable);
}
