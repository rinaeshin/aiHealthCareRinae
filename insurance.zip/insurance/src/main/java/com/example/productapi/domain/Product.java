package com.example.productapi.domain;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.*;

@Entity
@Table(name = "insurance_products", uniqueConstraints = {
        @UniqueConstraint(name = "uk_company_name", columnNames = {"company", "name"})
})
public class Product {
    @Id
    @Column(columnDefinition = "uuid")
    private UUID id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(name = "monthly_premium", nullable = false)
    private Integer monthlyPremium;

    @Column(nullable = false, length = 80)
    private String company;

    @Column(name = "company_logo_url", nullable = false)
    private String companyLogoUrl;

    @Column(columnDefinition = "text")
    private String description;

    @Column(name = "product_url", nullable = false)
    private String productUrl;

    @ElementCollection
    @CollectionTable(name = "insurance_product_tags", joinColumns = @JoinColumn(name = "product_id"))
    @Column(name = "tag")
    private Set<String> tags = new HashSet<>();

    @Column(nullable = false, length = 10)
    private String status; // draft|active|archived

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @OneToMany(mappedBy = "product", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.LAZY)
    @OrderBy("idx ASC")
    private List<ProductBenefit> benefits = new ArrayList<>();

    @PrePersist
    void prePersist() {
        if (id == null) id = UUID.randomUUID();
        Instant now = Instant.now();
        createdAt = now; updatedAt = now;
        if (status == null) status = "draft";
    }

    @PreUpdate
    void preUpdate() { updatedAt = Instant.now(); }

    public void setBenefits(List<ProductBenefit> list) {
        benefits.clear();
        if (list != null) {
            list.forEach(b -> b.setProduct(this));
            benefits.addAll(list);
        }
    }

    // other getters/setters omitted for brevity
    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getMonthlyPremium() { return monthlyPremium; }
    public void setMonthlyPremium(Integer monthlyPremium) { this.monthlyPremium = monthlyPremium; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getCompanyLogoUrl() { return companyLogoUrl; }
    public void setCompanyLogoUrl(String companyLogoUrl) { this.companyLogoUrl = companyLogoUrl; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getProductUrl() { return productUrl; }
    public void setProductUrl(String productUrl) { this.productUrl = productUrl; }
    public Set<String> getTags() { return tags; }
    public void setTags(Set<String> tags) { this.tags = tags; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(Instant updatedAt) { this.updatedAt = updatedAt; }
    public List<ProductBenefit> getBenefits() { return benefits; }
}
