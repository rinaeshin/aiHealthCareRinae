package com.example.productapi.web;

import com.example.productapi.dto.ProductDto;
import com.example.productapi.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.data.domain.*;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/products")
public class ProductPublicController {
    private final ProductService service;
    public ProductPublicController(ProductService service) { this.service = service; }

    @Operation(summary = "List products")
    @GetMapping
    public Page<ProductDto> list(
            @RequestParam(required = false) String q,
            @RequestParam(required = false) String company,
            @RequestParam(required = false) Integer priceMin,
            @RequestParam(required = false) Integer priceMax,
            @RequestParam(required = false, defaultValue = "active") String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(defaultValue = "monthlyPremium,asc") String sort
    ) {
        Pageable pageable = PageRequest.of(page, size, Sort.by(Sort.Order.by(sort.split(",")[0]).with("desc".equalsIgnoreCase(sort.split(",")[1]) ? Sort.Direction.DESC : Sort.Direction.ASC)));
        return service.list(q, company, priceMin, priceMax, status, pageable);
    }

    @Operation(summary = "Get product")
    @GetMapping("/{id}")
    public ProductDto get(@PathVariable("id") UUID id) { return service.get(id); }
}
