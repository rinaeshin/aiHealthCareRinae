package com.example.productapi.service;

import com.example.productapi.domain.*;
import com.example.productapi.dto.*;
import com.example.productapi.repo.ProductRepository;
import jakarta.persistence.EntityNotFoundException;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Transactional
public class ProductService {
    private final ProductRepository productRepo;

    public ProductService(ProductRepository productRepo) {
        this.productRepo = productRepo;
    }

    public ProductDto create(CreateProductReq req) {
        Product p = new Product();
        p.setName(req.name());
        p.setMonthlyPremium(req.monthlyPremium());
        p.setCompany(req.company());
        p.setCompanyLogoUrl(req.companyLogoUrl());
        p.setDescription(req.description());
        p.setProductUrl(req.productUrl());
        p.setTags(Optional.ofNullable(req.tags()).orElseGet(HashSet::new));
        p.setStatus(Optional.ofNullable(req.status()).orElse("draft"));

        // benefits
        List<ProductBenefit> bl = new ArrayList<>();
        List<String> benefits = Optional.ofNullable(req.benefits()).orElse(List.of());
        for (int i = 0; i < benefits.size(); i++) {
            ProductBenefit b = new ProductBenefit();
            b.setIdx(i);
            b.setBenefit(benefits.get(i));
            b.setProduct(p);
            bl.add(b);
        }
        p.setBenefits(bl);

        p = productRepo.save(p);
        return toDto(p);
    }

    @Transactional(readOnly = true)
    public Page<ProductDto> list(String q, String company, Integer priceMin, Integer priceMax, String status, Pageable pageable) {
        Page<Product> page = (company != null && !company.isBlank())
                ? productRepo.findByStatusAndCompanyContainingIgnoreCase(status == null ? "active" : status, company, pageable)
                : productRepo.findByStatus(status == null ? "active" : status, pageable);
        List<ProductDto> filtered = page.stream()
            .map(p -> filterAndMap(p, q, priceMin, priceMax))
            .filter(Objects::nonNull)
            .toList();
        return new PageImpl<>(filtered, pageable, page.getTotalElements());
    }

    @Transactional(readOnly = true)
    public ProductDto get(UUID id) {
        return productRepo.findById(id).map(this::toDto).orElseThrow(() -> new EntityNotFoundException("Product not found"));
    }

    public ProductDto patch(UUID id, Map<String, Object> fields) {
        Product p = productRepo.findById(id).orElseThrow(() -> new EntityNotFoundException("Product not found"));
        if (fields.containsKey("name")) p.setName((String) fields.get("name"));
        if (fields.containsKey("monthlyPremium")) p.setMonthlyPremium((Integer) fields.get("monthlyPremium"));
        if (fields.containsKey("company")) p.setCompany((String) fields.get("company"));
        if (fields.containsKey("companyLogoUrl")) p.setCompanyLogoUrl((String) fields.get("companyLogoUrl"));
        if (fields.containsKey("description")) p.setDescription((String) fields.get("description"));
        if (fields.containsKey("productUrl")) p.setProductUrl((String) fields.get("productUrl"));
        if (fields.containsKey("status")) p.setStatus((String) fields.get("status"));
        if (fields.containsKey("tags")) {
            @SuppressWarnings("unchecked") Set<String> tags = new HashSet<>((List<String>) fields.get("tags"));
            p.setTags(tags);
        }
        if (fields.containsKey("benefits")) {
            @SuppressWarnings("unchecked") List<String> list = (List<String>) fields.get("benefits");
            List<ProductBenefit> bl = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                ProductBenefit b = new ProductBenefit();
                b.setIdx(i); b.setBenefit(list.get(i)); b.setProduct(p); bl.add(b);
            }
            p.setBenefits(bl);
        }
        return toDto(p);
    }

    private ProductDto filterAndMap(Product p, String q, Integer priceMin, Integer priceMax) {
        if (q != null && !q.isBlank()) {
            String ql = q.toLowerCase();
            boolean hit = p.getName().toLowerCase().contains(ql)
                    || (p.getDescription() != null && p.getDescription().toLowerCase().contains(ql))
                    || p.getCompany().toLowerCase().contains(ql);
            if (!hit) return null;
        }
        if (priceMin != null && p.getMonthlyPremium() < priceMin) return null;
        if (priceMax != null && p.getMonthlyPremium() > priceMax) return null;
        return toDto(p);
    }

    private ProductDto toDto(Product p) {
        List<String> benefits = p.getBenefits().stream().map(ProductBenefit::getBenefit).toList();
        return new ProductDto(
                p.getId().toString(), p.getName(), p.getMonthlyPremium(), p.getCompany(), p.getCompanyLogoUrl(),
                p.getDescription(), p.getProductUrl(), p.getTags(), p.getStatus(), benefits, p.getCreatedAt(), p.getUpdatedAt());
    }
}
