package com.example.productapi.web;

import com.example.productapi.dto.*;
import com.example.productapi.service.ProductService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/admin/products")
public class ProductAdminController {
    private final ProductService service;
    public ProductAdminController(ProductService service) { this.service = service; }

    @Operation(summary = "Create product")
    @PostMapping
    public ProductDto create(@Valid @RequestBody CreateProductReq req) { return service.create(req); }

    @Operation(summary = "Patch product")
    @PatchMapping("/{id}")
    public ProductDto patch(@PathVariable UUID id, @RequestBody Map<String, Object> fields) { return service.patch(id, fields); }
}
