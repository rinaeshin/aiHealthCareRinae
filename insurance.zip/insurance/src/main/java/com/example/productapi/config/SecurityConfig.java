package com.example.productapi.config;

import org.springframework.context.annotation.*;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
    @Bean
    SecurityFilterChain filterChain(HttpSecurity http, ApiKeyFilter apiKeyFilter) throws Exception {
        http.csrf(csrf -> csrf.disable());
        http.addFilterBefore(apiKeyFilter, org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter.class);
        http.authorizeHttpRequests(reg -> reg
                .requestMatchers("/v3/api-docs/**", "/swagger-ui/**", "/swagger-ui.html").permitAll()
                .requestMatchers("/api/v1/products/**").permitAll() // ApiKeyFilter에서 키 검사
                .requestMatchers("/api/v1/admin/**").authenticated()
                .anyRequest().permitAll()
        );
        http.httpBasic(Customizer.withDefaults()); // 데모: 관리자 영역은 임시 basic; 실제론 JWT 권장
        return http.build();
    }
}
