package com.example.productapi.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.*;

public record ProductDto(
        @Schema(example = "c5e4a8b5-1e7e-4f6b-ae86-9a9c5c0af111") String id,
        @NotBlank @Size(max = 100) String name,
        @NotNull @Min(0) Integer monthlyPremium,
        @NotBlank String company,
        @NotBlank @Schema(example = "https://cdn.example.com/logos/a.png") String companyLogoUrl,
        String description,
        @NotBlank @Schema(example = "https://ins.example.com/p/123") String productUrl,
        Set<String> tags,
        @Pattern(regexp = "^(draft|active|archived)$") String status,
        List<String> benefits,
        Instant createdAt,
        Instant updatedAt
) {}
