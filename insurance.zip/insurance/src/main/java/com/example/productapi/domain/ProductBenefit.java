package com.example.productapi.domain;

import jakarta.persistence.*;

@Entity
@Table(name = "insurance_product_benefits")
public class ProductBenefit {
    @EmbeddedId
    private ProductBenefitId id = new ProductBenefitId();

    @MapsId("productId")
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "product_id")
    private Product product;

    @Column(nullable = false)
    private String benefit;

    // getters/setters
    public void setProduct(Product p) { this.product = p; this.id.setProductId(p.getId()); }
    public Product getProduct() { return product; }
    public void setBenefit(String benefit) { this.benefit = benefit; }
    public String getBenefit() { return benefit; }
    public void setIdx(int idx) { this.id.setIdx(idx); }
    public int getIdx() { return this.id.getIdx(); }
    public ProductBenefitId getId() { return id; }
    public void setId(ProductBenefitId id) { this.id = id; }
}
