package com.example.productapi.dto;

import jakarta.validation.constraints.*;
import java.util.*;

public record CreateProductReq(
        @NotBlank @Size(max = 100) String name,
        @NotNull @Min(0) Integer monthlyPremium,
        @NotBlank String company,
        @NotBlank String companyLogoUrl,
        String description,
        @NotBlank String productUrl,
        String detailUrl,
        Set<String> tags,
        @Pattern(regexp = "^(draft|active|archived)$") String status,
        List<@NotBlank String> benefits
) {}
