package com.example.productapi.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import java.io.Serializable;
import java.util.Objects;

@Embeddable
public class ProductBenefitId implements Serializable {
    @Column(name = "product_id", columnDefinition = "uuid")
    private java.util.UUID productId;
    private int idx;

    public java.util.UUID getProductId() { return productId; }
    public void setProductId(java.util.UUID productId) { this.productId = productId; }
    public int getIdx() { return idx; }
    public void setIdx(int idx) { this.idx = idx; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ProductBenefitId that = (ProductBenefitId) o;
        return idx == that.idx && Objects.equals(productId, that.productId);
    }
    @Override
    public int hashCode() {
        return Objects.hash(productId, idx);
    }
}

