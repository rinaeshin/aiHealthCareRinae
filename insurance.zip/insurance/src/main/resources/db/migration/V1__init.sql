CREATE TABLE insurance_products (
  id UUID PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  monthly_premium INTEGER NOT NULL CHECK (monthly_premium >= 0),
  company VARCHAR(80) NOT NULL,
  company_logo_url TEXT NOT NULL,
  description TEXT,
  product_url TEXT NOT NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'draft',
  created_at TIMESTAMP NOT NULL DEFAULT now(),
  updated_at TIMESTAMP NOT NULL DEFAULT now()
);

CREATE TABLE insurance_product_benefits (
  product_id UUID NOT NULL REFERENCES insurance_products(id) ON DELETE CASCADE,
  idx INT NOT NULL,
  benefit TEXT NOT NULL,
  PRIMARY KEY (product_id, idx)
);

CREATE TABLE insurance_product_tags (
  product_id UUID NOT NULL REFERENCES insurance_products(id) ON DELETE CASCADE,
  tag TEXT NOT NULL
);

CREATE UNIQUE INDEX uk_company_name ON insurance_products(company, name);
CREATE INDEX idx_products_company ON insurance_products(company);
CREATE INDEX idx_products_price ON insurance_products(monthly_premium);
CREATE INDEX idx_products_status ON insurance_products(status);
