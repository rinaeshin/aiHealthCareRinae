INSERT INTO insurance_products (id, name, monthly_premium, company, company_logo_url, description, product_url, status)
VALUES
 ('00000000-0000-0000-0000-000000000001','굿케어 실손 플러스',19000,'A손해보험','https://cdn.example.com/logos/a.png','만성질환 일부 특약 제외.','https://a.example.com/p/123','active'),
 ('00000000-0000-0000-0000-000000000002','스마트 종합 100',22000,'B생명','https://cdn.example.com/logos/b.png','3대 질병 진단비 강화.','https://b.example.com/p/987','active');

INSERT INTO insurance_product_benefits (product_id, idx, benefit) VALUES
 ('00000000-0000-0000-0000-000000000001',0,'1인실 입원비 보장'),
 ('00000000-0000-0000-0000-000000000001',1,'비급여 도수치료 제한'),
 ('00000000-0000-0000-0000-000000000002',0,'암/뇌/심장 진단비'),
 ('00000000-0000-0000-0000-000000000002',1,'갱신형');

INSERT INTO insurance_product_tags (product_id, tag) VALUES
 ('00000000-0000-0000-0000-000000000001','실손'),
 ('00000000-0000-0000-0000-000000000002','종합');
