INSERT INTO insurance_products (id, name, monthly_premium, company, company_logo_url, description, product_url, status, detail_url)
VALUES
 ('00000000-0000-0000-0000-000000000001','굿케어 실손 플러스',19000,'A손해보험','https://cdn.example.com/logos/a.png','만성질환 일부 특약 제외.','https://a.example.com/p/123','active', 'https://store.meritzfire.com/health-and-kids/custom-simple.do#!/'),
 ('00000000-0000-0000-0000-000000000002','스마트 종합 100',22000,'B생명','https://cdn.example.com/logos/b.png','3대 질병 진단비 강화.','https://b.example.com/p/987','active', 'https://dm.vitality.aia.co.kr/event/aia_cancer.jsp?cpcode=SWI064344&utm_source=google_pc&utm_medium=sa&utm_campaign=SA_11_%EA%B1%B4%EA%B0%95%ED%94%8C%EB%9F%AC%EC%8A%A4%EC%95%94%EB%B3%B4%ED%97%98_%2800-08%29&utm_content=%EA%B1%B4%ED%94%8C%EC%95%94_%EC%95%94%EB%B3%B4%ED%97%98_PC&utm_term=%EB%B3%B4%ED%97%98&gad_source=1&gad_campaignid=22573098945&gbraid=0AAAAADv0vI69YnE91znLmJLxyU9Zd8gIx&gclid=CjwKCAjwlt7GBhAvEiwAKal0ciGfKWatvC2z_ZiVRzpcARZQuUK1ewVf7e-45mRipB573ALpoVMJfRoCIM4QAvD_BwE'),
 ('00000000-0000-0000-0000-000000000003','DB손해보험 건강플랜',21000,'DB손해보험','https://cdn.example.com/logos/db.png','맞춤 건강플랜.','https://www.directdb.co.kr/ltm/prd/splcheal/custInfoView.do?searchPdcCd=31026','active', 'https://www.directdb.co.kr/ltm/prd/splcheal/custInfoView.do?searchPdcCd=31026&searchPdcTrtHistCd=00&pdcDvcd=l_health&selfPlanDvcd=2&partner_code=L245&_gl=1*1t9q9ki*_gcl_aw*R0NMLjE3NTkwMTc3MzYuQ2p3S0NBandsdDdHQmhBdkVpd0FLYWwwY25jUjZpdjlQNHFyaFV2b2xDZ1NQN2NjdDJUbi1UTVdTalZLVDBTSV81eW9oQ0tFdEx5TUV4b0N1RmdRQXZEX0J3RQ..*_gcl_au*MTk5ODM4OTk3OS4xNzU5MDE3NzI4*_ga*MzA5NTY1NTkzLjE3NTkwMTc3Mjg.*_ga_BNRVWN2S5D*czE3NTkwMTc3MjckbzEkZzEkdDE3NTkwMTc3MzYkajUxJGwwJGgw'),
 ('00000000-0000-0000-0000-000000000004','메리츠화재 토탈케어',20000,'메리츠화재','https://cdn.example.com/logos/meritz.png','토탈케어 건강보험.','https://www.meritzfire.com/health-and-kids/total-care.do#!/','active', 'https://www.meritzfire.com/health-and-kids/total-care.do#!/'),
 ('00000000-0000-0000-0000-000000000005','KB손해보험 건강보험',21000,'KB손해보험','https://cdn.example.com/logos/kb.png','KB손해보험 건강보험.','https://www.kbinsure.co.kr/CG302130001.ec','active', 'https://www.kbinsure.co.kr/CG302130001.ec'),
 ('00000000-0000-0000-0000-000000000006','흥국생명 건강보험',20500,'흥국생명','https://cdn.example.com/logos/heungkuk.png','흥국생명 건강보험.','https://www.heungkukdirect.com/main/0.html','active', 'https://www.heungkukdirect.com/main/0.html?utm_source=naverbs_pc&utm_medium=brand&utm_campaign=health&utm_content=main_pc_C_homelink&utm_term=%ED%9D%A5%EA%B5%AD%EC%83%9D%EB%AA%85&NaPm=ct%253Dmg2xrpk5%257Cci%253DER7ed01562-9bfe-11f0-9648-3609db12e6e8%257Ctr%253Dbrnd%257Chk%253Dc9757cca7a5f7f1d749b5097fc5c2b86e615f245%257Cnacn%253Dj6AFBwwyLVIq');

INSERT INTO insurance_product_benefits (product_id, idx, benefit) VALUES
 ('00000000-0000-0000-0000-000000000001',0,'1인실 입원비 보장'),
 ('00000000-0000-0000-0000-000000000001',1,'비급여 도수치료 제한'),
 ('00000000-0000-0000-0000-000000000002',0,'암/뇌/심장 진단비'),
 ('00000000-0000-0000-0000-000000000002',1,'갱신형');

INSERT INTO insurance_product_tags (product_id, tag) VALUES
 ('00000000-0000-0000-0000-000000000001','실손'),
 ('00000000-0000-0000-0000-000000000002','종합');
